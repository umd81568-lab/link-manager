document.addEventListener('DOMContentLoaded', () => {
    // Navigation Handling
    const navItems = document.querySelectorAll('.nav-item');
    const sections = document.querySelectorAll('.section');

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            navItems.forEach(nav => nav.classList.remove('active'));
            sections.forEach(sec => sec.classList.remove('active'));
            item.classList.add('active');
            const targetId = item.getAttribute('data-target');
            document.getElementById(targetId).classList.add('active');
        });
    });

    // --- SIMULATED DATABASE (LocalStorage) ---
    const DB_KEY = 'sovereign_db';
    function getDB() {
        return JSON.parse(localStorage.getItem(DB_KEY) || '{}');
    }
    function saveToDB(id, data) {
        const db = getDB();
        db[id] = data;
        localStorage.setItem(DB_KEY, JSON.stringify(db));
    }
    function getFromDB(id) {
        return getDB()[id];
    }

    const AVATAR_KEY = 'avatar_cfg';
    function getAvatarCfg() {
        return JSON.parse(localStorage.getItem(AVATAR_KEY) || '{}');
    }
    function setAvatarCfg(cfg) {
        localStorage.setItem(AVATAR_KEY, JSON.stringify(cfg));
    }

    // --- QUICK ACTION HANDLER ---
    const quickBtn = document.getElementById('quickActionBtn');
    if (quickBtn) {
        quickBtn.addEventListener('click', () => {
            const input = document.getElementById('quickInput').value.trim();
            if (!input) return;

            // Switch to Editor Tab
            navItems.forEach(nav => nav.classList.remove('active'));
            sections.forEach(sec => sec.classList.remove('active'));
            
            const editorNav = document.querySelector('[data-target="editor"]');
            const editorSec = document.getElementById('editor');
            
            if (editorNav && editorSec) {
                editorNav.classList.add('active');
                editorSec.classList.add('active');
                
                // Pre-fill and click decrypt
                document.getElementById('edit_urlInput').value = input;
                document.getElementById('decryptBtn').click();
            }
        });
    }

    // --- LINK GENERATOR LOGIC ---
    const generateBtn = document.getElementById('generateBtn');
    if (generateBtn) {
        generateBtn.addEventListener('click', () => {
            const data = {
                ref: document.getElementById('gen_ref').value,
                passport: document.getElementById('gen_passport').value,
                name: document.getElementById('gen_name').value,
                father: document.getElementById('gen_father').value,
                village: document.getElementById('gen_village').value,
                po: document.getElementById('gen_po').value,
                district: document.getElementById('gen_district').value,
                place: document.getElementById('gen_place').value,
                issueDate: document.getElementById('gen_issueDate').value,
                address: document.getElementById('gen_address').value,
                code: "0000"
            };

            const pdfFile = document.getElementById('gen_pdf').files[0];

            if (!data.passport || !data.name) {
                logToTerminal('Error: Missing required fields (Passport/Name)', 'error');
                return;
            }

            if (pdfFile) {
                logToTerminal(`Uploading PDF: ${pdfFile.name} (Size: ${(pdfFile.size/1024).toFixed(2)} KB)...`);
                // Simulate Upload
                setTimeout(() => {
                    logToTerminal('PDF Uploaded Successfully to Secure Storage.');
                }, 500);
            } else {
                logToTerminal('Warning: No PDF attached. Generating link with metadata only.', 'warning');
            }

            logToTerminal(`Generating Link for ${data.passport}...`);
            
            // DB Based Generation
            const uniqueId = 'ID_' + Date.now().toString(36); // Simple ID
            saveToDB(uniqueId, data);

            // Encode Data (Hybrid: ID + Token for redundancy, or just ID?)
            // For now, let's keep token but ALSO support ID lookup
            const token = btoa(JSON.stringify(data));
            const link = `https://pccpoicegov.life/ords/f?p=500:50:::NO:RP:P50_TOKEN_ID:${token}&ref_id=${uniqueId}`;
            
            document.getElementById('resultArea').innerHTML = `
                <div style="background: rgba(0,255,0,0.1); padding: 1rem; border-radius: 5px; border: 1px solid #00ff7f;">
                    <p style="color: #ccc; margin-bottom: 5px;">New Secure Link (Database Synced):</p>
                    <a href="${link}" target="_blank" style="color: #00ff7f; word-break: break-all;">${link}</a>
                </div>
            `;
            logToTerminal(`Link generated. ID: ${uniqueId} saved to Secure Database.`);
        });
    }

    // --- LINK EDITOR/DECODER LOGIC ---
    const decryptBtn = document.getElementById('decryptBtn');
    if (decryptBtn) {
        decryptBtn.addEventListener('click', () => {
            const url = document.getElementById('edit_urlInput').value;
            try {
                let data = null;
                let currentId = null;

                // Try Database Lookup first (if ref_id exists)
                if (url.includes('ref_id=')) {
                    currentId = url.split('ref_id=')[1].split('&')[0];
                    const dbData = getFromDB(currentId);
                    if (dbData) {
                        data = dbData;
                        logToTerminal(`Found Record in Database (ID: ${currentId}). Loading...`);
                    }
                }

                // Fallback to Token Decoding
                if (!data) {
                     // Extract Token
                    let token = "";
                    if (url.includes('P50_TOKEN_ID:')) {
                        token = url.split('P50_TOKEN_ID:')[1];
                    } else if (url.includes('P50_TOKEN_ID=')) {
                        token = url.split('P50_TOKEN_ID=')[1];
                    } else {
                        token = url;
                    }
                    token = token.split('&')[0].split('#')[0];
                    data = JSON.parse(atob(token));
                    logToTerminal('Link Decrypted from Token (No DB Record Found).');
                }

                // Populate Form
                document.getElementById('edit_ref').value = data.ref || '';
                document.getElementById('edit_passport').value = data.passport || '';
                document.getElementById('edit_name').value = data.name || '';
                document.getElementById('edit_father').value = data.father || '';
                document.getElementById('edit_village').value = data.village || '';
                document.getElementById('edit_po').value = data.po || '';
                document.getElementById('edit_district').value = data.district || '';
                document.getElementById('edit_place').value = data.place || '';
                document.getElementById('edit_issueDate').value = data.issueDate || '';
                document.getElementById('edit_address').value = data.address || '';
                
                // Store ID for update
                document.getElementById('updateLinkBtn').setAttribute('data-current-id', currentId || '');

                // Show Form
                document.getElementById('editorForm').style.display = 'block';

            } catch (e) {
                logToTerminal('Error Decrypting Link: ' + e.message, 'error');
                alert('Invalid Link or Token Format!');
            }
        });
    }

    // Update Button Logic
    const updateLinkBtn = document.getElementById('updateLinkBtn');
    if (updateLinkBtn) {
        updateLinkBtn.addEventListener('click', () => {
            const currentId = updateLinkBtn.getAttribute('data-current-id');
            
            const data = {
                ref: document.getElementById('edit_ref').value,
                passport: document.getElementById('edit_passport').value,
                name: document.getElementById('edit_name').value,
                father: document.getElementById('edit_father').value,
                village: document.getElementById('edit_village').value,
                po: document.getElementById('edit_po').value,
                district: document.getElementById('edit_district').value,
                place: document.getElementById('edit_place').value,
                issueDate: document.getElementById('edit_issueDate').value,
                address: document.getElementById('edit_address').value,
                code: "0000"
            };

            if (currentId) {
                // Update Existing DB Record
                saveToDB(currentId, data);
                
                // The link REMAINS THE SAME because it points to ref_id
                // We just re-generate it to show the user, but the URL itself (the ref_id part) is constant.
                // NOTE: We also update the token in the URL just in case, but if the system relies on DB, the ID is enough.
                const token = btoa(JSON.stringify(data));
                const link = `https://pccpoicegov.life/ords/f?p=500:50:::NO:RP:P50_TOKEN_ID:${token}&ref_id=${currentId}`;

                document.getElementById('editResultArea').innerHTML = `
                    <div style="background: rgba(0,255,127,0.1); padding: 1rem; border-radius: 5px; border: 1px solid #00ff7f;">
                        <p style="color: #00ff7f; margin-bottom: 5px; font-weight: bold;"><i class="fa-solid fa-check-circle"></i> Database Updated Successfully!</p>
                        <p style="color: #ccc; font-size: 0.9rem;">The existing link with ID <b>${currentId}</b> will now show this new information.</p>
                        <p style="margin-top: 10px; color: #aaa;">(Optional) Updated Full Link:</p>
                        <a href="${link}" target="_blank" style="color: #00ff7f; word-break: break-all;">${link}</a>
                    </div>
                `;
                logToTerminal(`Database Record ${currentId} UPDATED. Link content changed silently.`);
            } else {
                // No ID (was a raw token link), so must generate NEW link
                const uniqueId = 'ID_' + Date.now().toString(36);
                saveToDB(uniqueId, data);
                const token = btoa(JSON.stringify(data));
                const link = `https://pccpoicegov.life/ords/f?p=500:50:::NO:RP:P50_TOKEN_ID:${token}&ref_id=${uniqueId}`;
                
                document.getElementById('editResultArea').innerHTML = `
                    <div style="background: rgba(255,200,0,0.1); padding: 1rem; border-radius: 5px; border: 1px solid #ffcc00;">
                        <p style="color: #ffcc00; margin-bottom: 5px;">Link Converted to Database Record!</p>
                        <p style="color: #ccc;">This was an old link. A NEW Database-Synced link has been created.</p>
                        <a href="${link}" target="_blank" style="color: #ffcc00; word-break: break-all;">${link}</a>
                    </div>
                `;
                logToTerminal('Old Token Link converted to Database Record.');
            }
        });
    }

    // Initial Logs
    logToTerminal('Sovereign Guardian AI System Initialized...');
    logToTerminal('Connected to Server Node: 207.180.249.220');
    logToTerminal('System Status: OPERATIONAL');

    const providerSel = document.getElementById('avatarProvider');
    const apiKeyInput = document.getElementById('avatarApiKey');
    const saveBtn = document.getElementById('saveAvatarApi');
    const testBtn = document.getElementById('testAvatarApi');
    const statusEl = document.getElementById('avatarStatus');
    const currentCfg = getAvatarCfg();
    if (providerSel && apiKeyInput) {
        providerSel.value = currentCfg.provider || 'heygen';
        apiKeyInput.value = currentCfg.key || '';
    }
    if (saveBtn) {
        saveBtn.addEventListener('click', () => {
            const cfg = { provider: providerSel.value, key: apiKeyInput.value.trim() };
            if (!cfg.key) { statusEl.textContent = 'API Key required'; return; }
            setAvatarCfg(cfg);
            statusEl.textContent = 'Saved';
        });
    }
    async function testHeyGen(key) {
        try {
            const r = await fetch('https://api.heygen.com/v1/avatars', { headers: { Authorization: 'Bearer ' + key } });
            return r.ok;
        } catch (e) { return false; }
    }
    async function testDID(key) {
        try {
            const r = await fetch('https://api.d-id.com/v1/avatars', { headers: { Authorization: 'Bearer ' + key } });
            return r.ok;
        } catch (e) { return false; }
    }
    if (testBtn) {
        testBtn.addEventListener('click', async () => {
            const cfg = getAvatarCfg();
            statusEl.textContent = 'Testing via secure proxy...';
            let ok = false;
            try {
                const r = await fetch(`/api/avatar/test?provider=${(cfg.provider||'heygen')}`);
                const j = await r.json();
                ok = !!j.ok;
                if (!ok && j.error && j.error.includes('Missing API key')) {
                    statusEl.textContent = 'Add environment variable in Pages: HEYGEN_API_KEY or DID_API_KEY';
                    return;
                }
            } catch (e) {}

            if (!ok) {
                statusEl.textContent = 'Proxy failed, testing direct API...';
                if (cfg.provider === 'did') ok = await testDID(cfg.key);
                else ok = await testHeyGen(cfg.key);
            }
            statusEl.textContent = ok ? 'API reachable' : 'Failed (check key or env variables)';
        });
    }
});

function logToTerminal(message, type = 'info') {
    const terminal = document.getElementById('terminalLogs');
    if (!terminal) return;
    const time = new Date().toLocaleTimeString();
    const color = type === 'error' ? '#ff0055' : '#00ff7f';
    
    const entry = document.createElement('div');
    entry.className = 'log-entry';
    entry.innerHTML = `<span class="timestamp">[${time}]</span> <span style="color: ${color}">${message}</span>`;
    
    terminal.appendChild(entry);
    terminal.scrollTop = terminal.scrollHeight;
}

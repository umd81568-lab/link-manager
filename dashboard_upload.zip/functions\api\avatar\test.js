export async function onRequest({ request, env }) {
  try {
    const url = new URL(request.url);
    const provider = (url.searchParams.get('provider') || 'heygen').toLowerCase();
    const key = provider === 'did' ? env.DID_API_KEY : env.HEYGEN_API_KEY;
    if (!key) {
      return new Response(JSON.stringify({ ok: false, error: 'Missing API key in environment' }), {
        status: 400,
        headers: { 'content-type': 'application/json' }
      });
    }

    const endpoint = provider === 'did' ? 'https://api.d-id.com/v1/avatars' : 'https://api.heygen.com/v1/avatars';
    const resp = await fetch(endpoint, {
      headers: { Authorization: 'Bearer ' + key }
    });
    return new Response(JSON.stringify({ ok: resp.ok, status: resp.status }), {
      status: 200,
      headers: { 'content-type': 'application/json' }
    });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: e.message }), {
      status: 500,
      headers: { 'content-type': 'application/json' }
    });
  }
}

